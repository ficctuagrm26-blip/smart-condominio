import { useEffect, useMemo, useState } from "react";
import { listDashboardIntents, verifyReceipt, listReceiptsByIntent } from "../api/payments";
import { getRole, me } from "../api/auth";

function isImage(url = "") {
  const u = (url || "").toLowerCase();
  return u.endsWith(".png") || u.endsWith(".jpg") || u.endsWith(".jpeg") || u.endsWith(".gif") || u.includes("image");
}

const PENDING_STATES = new Set(["PENDING","REVIEW","SUBMITTED","UPLOADED","EN_REVISION","POR_REVISAR"]);

// Enriquecer intents con sus comprobantes haciendo GET a /pagos/mock/receipt/?intent=ID
async function hydrateIntentsWithReceipts(intents) {
  const enriched = await Promise.all(
    intents.map(async (it) => {
      try {
        const receipts = await listReceiptsByIntent(it.id);
        return { ...it, receipts };
      } catch {
        return { ...it, receipts: [] };
      }
    })
  );
  return enriched;
}

export default function AdminPagosPage() {
  const [loading, setLoading] = useState(false);
  const [intents, setIntents] = useState([]);
  const [err, setErr] = useState("");
  const [preview, setPreview] = useState(null);
  const [allowed, setAllowed] = useState(true);

  // Proteger por rol (opcional)
  useEffect(() => {
    (async () => {
      try {
        const user = await me().catch(() => null);
        const role = getRole(user);
        setAllowed(role === "ADMIN" || role === "STAFF" || (user?.is_superuser ?? false));
      } catch {
        setAllowed(true);
      }
    })();
  }, []);

  const refresh = async () => {
    setLoading(true);
    setErr("");
    try {
      const raw = await listDashboardIntents();
      const base = Array.isArray(raw) ? raw : (raw?.data || raw?.results || []);
      // <-- AQUÍ: enriquecemos con comprobantes reales
      const hydrated = await hydrateIntentsWithReceipts(base);
      console.log("[dashboard intents] base=", base.length, " hydrated=", hydrated.length);
      setIntents(hydrated);
    } catch (e) {
      console.error(e);
      setErr(e.message || "Error al cargar dashboard");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { refresh(); }, []);

  // Aplana comprobantes
  const receiptsFlat = useMemo(() => {
    const rows = [];
    for (const it of intents) {
      const rs = Array.isArray(it.receipts) ? it.receipts : [];
      for (const r of rs) {
        rows.push({
          intent_id: it.id,
          cuota: it.cuota?.id || it.cuota || "-",
          amount_intent: it.amount,
          currency: it.currency || "BOB",
          user_display: it.user_display || it.user || it.creado_por || "-",
          intent_status: it.status,
          created_at: it.created_at,
          // receipt
          receipt_id: r.id,
          receipt_amount: r.amount,
          bank_name: r.bank_name,
          reference: r.reference,
          receipt_url: r.receipt_url || r.url || r.link,
          receipt_status: String(r.status || "").toUpperCase(),
          submitted_at: r.submitted_at || r.created_at || it.created_at,
        });
      }
    }
    rows.sort((a, b) => new Date(b.submitted_at || 0) - new Date(a.submitted_at || 0));
    return rows;
  }, [intents]);

  const pendingOnly = receiptsFlat.filter(
    r => !["APPROVED","REJECTED"].includes(r.receipt_status) || PENDING_STATES.has(r.receipt_status)
  );

  const onAction = async (row, approve) => {
    try {
      await verifyReceipt({ receipt_id: row.receipt_id, approve });
      await refresh();
    } catch (e) {
      console.error(e);
      alert(e.message || "No se pudo actualizar");
    }
  };

  if (!allowed) {
    return <div className="page"><h2>Pagos – Admin</h2><p>No autorizado.</p></div>;
  }

  return (
    <div className="page">
      <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
        <h2>Pagos – Verificación</h2>
        <button className="btn btn--ghost" onClick={refresh}>Actualizar</button>
      </div>

      {loading && <div>Cargando…</div>}
      {err && <p className="alert alert--err">{err}</p>}

      {/* DEBUG opcional */}
      {intents.length > 0 && (
        <details style={{ margin: "12px 0" }}>
          <summary>DEBUG: ver primer intento con receipts</summary>
          <pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(intents[0], null, 2)}</pre>
        </details>
      )}

      <section style={{ marginTop: 8 }}>
        <h3>Pendientes</h3>
        <div className="table">
          <div className="thead">
            <div>ID Comp.</div>
            <div>Intento</div>
            <div>Usuario</div>
            <div>Cuota</div>
            <div>Monto (intent)</div>
            <div>Monto (recibo)</div>
            <div>Banco</div>
            <div>Referencia</div>
            <div>Comprobante</div>
            <div>Acción</div>
          </div>
          <div className="tbody">
            {pendingOnly.map((r) => (
              <div className="tr" key={`p-${r.receipt_id}`}>
                <div>#{r.receipt_id}</div>
                <div>#{r.intent_id}</div>
                <div>{r.user_display}</div>
                <div>{String(r.cuota)}</div>
                <div>{r.amount_intent} {r.currency}</div>
                <div>{r.receipt_amount ?? "-"}</div>
                <div>{r.bank_name || "-"}</div>
                <div>{r.reference || "-"}</div>
                <div>
                  {r.receipt_url ? (
                    <button className="btn btn--ghost"
                      onClick={() => setPreview({ url: r.receipt_url, title: `Comp. #${r.receipt_id}` })}>
                      {isImage(r.receipt_url) ? "Ver imagen" : "Abrir enlace"}
                    </button>
                  ) : "-"}
                </div>
                <div className="row" style={{ gap: 6 }}>
                  <button className="btn btn--primary" onClick={() => onAction(r, true)}>Aprobar</button>
                  <button className="btn btn--info" onClick={() => onAction(r, false)}>Rechazar</button>
                </div>
              </div>
            ))}
            {pendingOnly.length === 0 && (
              <div className="tr"><div>No hay comprobantes pendientes.</div></div>
            )}
          </div>
        </div>
      </section>

      <section style={{ marginTop: 24 }}>
        <h3>Todos los intentos (resumen)</h3>
        <div className="table">
          <div className="thead">
            <div>ID</div><div>Usuario</div><div>Cuota</div><div>Monto</div><div>Status</div><div>Creado</div><div>Comprobantes</div>
          </div>
          <div className="tbody">
            {intents.map((i) => (
              <div className="tr" key={i.id}>
                <div>#{i.id}</div>
                <div>{i.user_display || i.user || i.creado_por || "-"}</div>
                <div>{i.cuota?.id || i.cuota || "-"}</div>
                <div>{i.amount} {i.currency || "BOB"}</div>
                <div>{i.status}</div>
                <div>{i.created_at ? new Date(i.created_at).toLocaleString() : "-"}</div>
                <div>{Array.isArray(i.receipts) ? i.receipts.length : 0}</div>
              </div>
            ))}
            {intents.length === 0 && <div className="tr"><div>Sin intentos.</div></div>}
          </div>
        </div>
      </section>

      {preview && (
        <div className="modal-backdrop modal-backdrop--show" onClick={() => setPreview(null)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-card__head">
              <h3 style={{ margin: 0 }}>{preview.title}</h3>
              <button className="btn btn--ghost" onClick={() => setPreview(null)}>✕</button>
            </div>
            {isImage(preview.url)
              ? <img src={preview.url} alt="Comprobante" style={{ maxWidth: "100%", borderRadius: 12 }} />
              : <a href={preview.url} target="_blank" rel="noreferrer" className="btn btn--primary as-link">Abrir enlace</a>}
          </div>
        </div>
      )}
    </div>
  );
}
