import { useEffect, useState } from "react";
import {
  getDashboardIntents,
  verificarComprobante
} from "../api/payments";

export default function RevisarComprobantesPage() {
  const [intents, setIntents] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const data = await getDashboardIntents();
      setIntents(data);
    } catch (err) {
      console.error(err);
      alert("Error cargando intents");
    }
    setLoading(false);
  }

  async function handleVerificar(receipt_id, approve) {
    const note = !approve ? prompt("Motivo de rechazo:") : "";
    try {
      await verificarComprobante({ receipt_id, approve, note });
      alert(approve ? "Aprobado ✅" : "Rechazado ❌");
      load();
    } catch (err) {
      console.error(err);
      alert("Error verificando comprobante");
    }
  }

  return (
    <div>
      <h1>Revisión de Comprobantes</h1>
      {loading && <p>Cargando...</p>}
      {intents.map(intent => (
        <div key={intent.id} style={{ border: "1px solid #ccc", margin: 8, padding: 8 }}>
          <p><b>Unidad:</b> {intent.metadata?.unidad_display}</p>
          <p><b>Cuota:</b> {intent.cuota?.periodo} - {intent.cuota?.concepto}</p>
          <p><b>Monto:</b> {intent.amount}</p>
          <p><b>Estado:</b> {intent.status}</p>

          {intent.receipts && intent.receipts.length > 0 && (
            <div>
              <h4>Comprobante</h4>
              {intent.receipts.map(r => (
                <div key={r.id}>
                  <a href={r.receipt_url} target="_blank" rel="noreferrer">Ver comprobante</a>
                  <p>Referencia: {r.reference}</p>
                  <button onClick={() => handleVerificar(r.id, true)}>Aprobar</button>
                  <button onClick={() => handleVerificar(r.id, false)}>Rechazar</button>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
