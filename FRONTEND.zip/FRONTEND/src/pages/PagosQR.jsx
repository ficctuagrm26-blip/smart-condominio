// src/pages/PagosQR.jsx (REEMPLAZO COMPLETO)
import { useEffect, useMemo, useState } from "react";
import {
  getMisCuotas,
  crearIntentoPago,
  subirComprobante,
  subirComprobanteArchivo,
  getMyIntents,
} from "../api/payments";

function fmtMoney(n) {
  const v = Number(n || 0);
  return isNaN(v) ? n : `Bs. ${v.toFixed(2)}`;
}
function isPending(c) {
  const s = String(c?.estado || "").toUpperCase();
  return s === "PENDIENTE" || s === "VENCIDA" || s === "PARCIAL";
}

export default function PagosQR() {
  const [loading, setLoading] = useState(true);
  const [cuotas, setCuotas] = useState([]);
  const [intents, setIntents] = useState([]);
  const [error, setError] = useState("");
  const [uploadOpen, setUploadOpen] = useState(null); // {cuotaId, intentId}

  async function loadAll() {
    setLoading(true);
    setError("");
    try {
      // Ambos endpoints ya devuelven listas normalizadas
      const [cs, its] = await Promise.all([getMisCuotas(), getMyIntents()]);
      setCuotas(Array.isArray(cs) ? cs : []);
      setIntents(Array.isArray(its) ? its : []);
    } catch (e) {
      console.error(e);
      setError(e?.detail || "No se pudo cargar");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { loadAll(); }, []);

  const visibles = useMemo(() => {
    return (cuotas || []).filter(c => Number(c?.saldo || 0) > 0 && isPending(c));
  }, [cuotas]);

  function intentByCuotaId(cuotaId) {
    const c = cuotas.find(x => x.id === cuotaId);
    const base = c?.ultimo_intento ? [c.ultimo_intento] : [];
    const more = intents.filter(it => (it.cuota?.id ?? it.cuota) === cuotaId);
    const merged = [...base, ...more].filter(Boolean)
      .sort((a,b) => new Date(b.created_at||0) - new Date(a.created_at||0));
    return merged[0] || null;
    }

  async function onCrearQR(c) {
    try {
      const it = await crearIntentoPago(c.id, "QR");
      alert("Intento generado. Abre el enlace o escanea el QR.");
      await loadAll();
      setUploadOpen({ cuotaId: c.id, intentId: it.id });
    } catch (e) {
      console.error(e);
      alert(e?.detail || "No se pudo generar el QR");
    }
  }

  async function onSubirComprobanteLink({ cuotaId, intentId }) {
    const receipt_url = prompt("Pega la URL del comprobante (Drive/Imgur/Cloudinary, etc):");
    if (!receipt_url) return;
    try {
      const cuota = cuotas.find(x => x.id === cuotaId);
      await subirComprobante({
        intent: intentId,
        receipt_url,
        amount: cuota?.saldo,
        reference: `TRX-${Date.now()}`,
        bank_name: "Banco (simulado)"
      });
      alert("Comprobante enviado ✅");
      setUploadOpen(null);
      await loadAll();
    } catch (e) {
      console.error(e);
      alert(e?.detail || "Error subiendo comprobante");
    }
  }

  async function onSubirComprobanteArchivo({ cuotaId, intentId }, file) {
    if (!file) return;
    try {
      const cuota = cuotas.find(x => x.id === cuotaId);
      await subirComprobanteArchivo({
        intent: intentId,
        file,
        amount: cuota?.saldo,
        reference: `TRX-${Date.now()}`,
        bank_name: "Banco (simulado)",
      });
      alert("Comprobante enviado ✅");
      setUploadOpen(null);
      await loadAll();
    } catch (e) {
      console.error(e);
      alert(e?.detail || "Error subiendo archivo");
    }
  }

  function qrImg(confirmation_url) {
    if (!confirmation_url) return null;
    const src = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(confirmation_url)}`;
    return <img src={src} alt="QR" style={{ width: 180, height: 180 }} />;
  }

  return (
    <div className="page">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2>Pagos por QR</h2>
        <button className="btn btn--ghost" onClick={loadAll}>Actualizar</button>
      </div>

      {loading && <p>Cargando…</p>}
      {error && <p className="alert alert--err">{error}</p>}
      {visibles.length === 0 && !loading && <p>No tienes cuotas pendientes con saldo.</p>}

      <div className="cards" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 12 }}>
        {visibles.map(c => {
          const it = intentByCuotaId(c.id);
          const confirmation_url = it?.confirmation_url || it?.qr_payload || c?.ultimo_intento?.confirmation_url;
          return (
            <div key={c.id} className="card" style={{ padding: 12, border: "1px solid #e5e7eb", borderRadius: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <strong>{c.periodo} — {c.concepto}</strong>
                <span style={{ color: "#6b7280" }}>{c.unidad_display || c.unidad}</span>
              </div>
              <div style={{ marginTop: 4, fontSize: 14, color: "#374151" }}>
                Total: {fmtMoney(c.total_a_pagar)} · Pagado: {fmtMoney(c.pagado)} · <b>Saldo: {fmtMoney(c.saldo)}</b>
              </div>
              <div style={{ marginTop: 4, fontSize: 13, color: "#6b7280" }}>
                Vence: {c.vencimiento} · Estado: {c.estado}
              </div>

              <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
                <button className="btn btn--primary" onClick={() => onCrearQR(c)}>
                  {it ? "Regenerar QR" : "Generar QR"}
                </button>
                <button className="btn" onClick={() => setUploadOpen({ cuotaId: c.id, intentId: it?.id || c?.ultimo_intento?.id })} disabled={!it && !c?.ultimo_intento}>
                  Subir comprobante
                </button>
                {confirmation_url && (
                  <a href={confirmation_url} target="_blank" rel="noreferrer" className="btn btn--ghost">
                    Abrir enlace
                  </a>
                )}
              </div>

              <div style={{ marginTop: 10 }}>
                {confirmation_url ? qrImg(confirmation_url) : <small className="muted">Aún no hay QR generado.</small>}
              </div>

              {uploadOpen?.cuotaId === c.id && (
                <div style={{ marginTop: 12, padding: 10, border: "1px dashed #d1d5db", borderRadius: 8 }}>
                  <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
                    <input type="file" accept="image/*,application/pdf"
                      onChange={(e) => onSubirComprobanteArchivo(uploadOpen, e.target.files?.[0])} />
                    <button className="btn" onClick={() => onSubirComprobanteLink(uploadOpen)}>Pegar URL</button>
                    <button className="btn btn--ghost" onClick={() => setUploadOpen(null)}>Cerrar</button>
                  </div>
                  <small className="muted">Puedes subir archivo o pegar el enlace de tu comprobante.</small>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
