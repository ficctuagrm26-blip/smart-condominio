// src/components/PayModal.jsx
import { useEffect, useMemo, useState } from "react";
import QRCode from "qrcode";
import { createCheckout, getLanding, uploadReceipt } from "../api/payments";

export default function PayModal({ open, onClose, cuota, onSuccess }) {
  const [medio, setMedio] = useState("QR");
  const [creating, setCreating] = useState(false);
  const [intent, setIntent] = useState(null);
  const [error, setError] = useState("");

  // QR
  const [qrUrl, setQrUrl] = useState("");
  const [qrPng, setQrPng] = useState("");

  // Form comprobante
  const [receipt, setReceipt] = useState({
    receipt_url: "",
    amount: "",
    reference: "",
    bank_name: "Banco Union",
    file: null,
  });
  const [uploading, setUploading] = useState(false);
  const [uploadMsg, setUploadMsg] = useState("");

  useEffect(() => {
    if (!open) {
      setCreating(false);
      setIntent(null);
      setError("");
      setQrUrl("");
      setQrPng("");
      setReceipt({ receipt_url: "", amount: "", reference: "", bank_name: "Banco Union", file: null });
      setUploadMsg("");
    }
  }, [open]);

  useEffect(() => {
    let cancelled = false;
    async function gen() {
      if (!qrUrl) return setQrPng("");
      try {
        const dataUrl = await QRCode.toDataURL(qrUrl, {
          margin: 1,
          width: 256,
          errorCorrectionLevel: "M",
        });
        if (!cancelled) setQrPng(dataUrl);
      } catch (e) {
        if (!cancelled) setQrPng("");
      }
    }
    gen();
    return () => { cancelled = true; };
  }, [qrUrl]);

  const canCreate = useMemo(() => !!cuota?.id && !creating && !intent, [cuota, creating, intent]);

  const onCreateIntent = async () => {
    try {
      setCreating(true);
      setError("");
      const data = await createCheckout({ cuota: cuota.id, medio });
      setIntent(data);
      setQrUrl(data.qr_payload || data.confirmation_url || "");
    } catch (e) {
      setError(e.message);
    } finally {
      setCreating(false);
    }
  };

  const onMarkScanned = async () => {
    try {
      if (!intent?.confirmation_url) return;
      await getLanding(intent.confirmation_url);
      alert("Escaneo OK: ahora sube el comprobante.");
    } catch (e) {
      setError(e.message);
    }
  };

  const onSubmitReceipt = async (e) => {
    e?.preventDefault?.();
    if (!intent?.id) return;

    try {
      setUploading(true);
      setError("");
      setUploadMsg("");
      const payload = {
        intent: intent.id,
        receipt_url: receipt.receipt_url || undefined,
        amount: receipt.amount || undefined,
        reference: receipt.reference || undefined,
        bank_name: receipt.bank_name || undefined,
        file: receipt.file || undefined,
      };
      const data = await uploadReceipt(payload);
      setUploadMsg(`Comprobante #${data.id} enviado. Espera verificación de ADMIN/STAFF.`);
      onSuccess?.();
      onClose?.();
    } catch (e) {
      setError(e.message);
    } finally {
      setUploading(false);
    }
  };

  if (!open || !cuota) return null;

  return (
    <div className="modal-backdrop modal-backdrop--show">
      <div className="modal-card" role="dialog" aria-modal="true" aria-labelledby="pay-title">
        <div className="modal-card__head">
          <div>
            <h3 id="pay-title">Pago de cuota #{cuota.id}</h3>
            <p className="muted">
              {cuota.unidad_display} • {cuota.periodo} • Saldo: <b>{Number(cuota.saldo).toFixed(2)}</b>
            </p>
          </div>
          <button className="btn btn--ghost" onClick={onClose} aria-label="Cerrar">✕</button>
        </div>

        {!intent && (
          <div className="stack gap-12">
            <label className="field">
              <span className="field__label">Método</span>
              <select value={medio} onChange={(e) => setMedio(e.target.value)} className="field__control">
                <option value="QR">QR</option>
                <option value="CARD">Tarjeta (Mock)</option>
              </select>
            </label>
            <button className="btn btn--primary" disabled={!canCreate} onClick={onCreateIntent}>
              {creating ? "Creando..." : "Crear intento"}
            </button>
          </div>
        )}

        {intent && (
          <>
            <div className="grid-2">
              {/* Columna QR */}
              <div className="card">
                <div className="card__head">
                  <b>Escanear / Abrir link</b>
                  <span className="pill">{intent.status}</span>
                </div>

                <div className="qr-box">
                  {qrPng ? (
                    <img src={qrPng} alt="QR" className="qr-box__img" />
                  ) : (
                    <div className="qr-box__placeholder">Generando QR…</div>
                  )}
                </div>

                <code className="code-wrap">{qrUrl || intent.confirmation_url}</code>

                <div className="row gap-8">
                  <button className="btn btn--ghost"
                          onClick={() => navigator.clipboard.writeText(qrUrl || intent.confirmation_url)}>
                    Copiar link
                  </button>
                  <a href={intent.confirmation_url} target="_blank" rel="noopener noreferrer" className="btn btn--ghost as-link">
                    Abrir
                  </a>
                  <button className="btn btn--info" onClick={onMarkScanned}>Ya lo escaneé</button>
                </div>
              </div>

              {/* Columna Formulario */}
              <form onSubmit={onSubmitReceipt} className="card">
                <div className="card__head"><b>Subir comprobante</b></div>

                <label className="field">
                  <span className="field__label">URL del comprobante</span>
                  <input
                    value={receipt.receipt_url}
                    onChange={(e) => setReceipt((s) => ({ ...s, receipt_url: e.target.value }))}
                    placeholder="https://..."
                    className="field__control"
                  />
                </label>

                <div className="grid-2--compact">
                  <label className="field">
                    <span className="field__label">Monto (opcional)</span>
                    <input
                      type="number"
                      step="0.01"
                      value={receipt.amount}
                      onChange={(e) => setReceipt((s) => ({ ...s, amount: e.target.value }))}
                      placeholder="150.00"
                      className="field__control"
                    />
                  </label>
                  <label className="field">
                    <span className="field__label">Referencia</span>
                    <input
                      value={receipt.reference}
                      onChange={(e) => setReceipt((s) => ({ ...s, reference: e.target.value }))}
                      placeholder="TRX123"
                      className="field__control"
                    />
                  </label>
                </div>

                <label className="field">
                  <span className="field__label">Banco</span>
                  <input
                    value={receipt.bank_name}
                    onChange={(e) => setReceipt((s) => ({ ...s, bank_name: e.target.value }))}
                    placeholder="Banco Unión"
                    className="field__control"
                  />
                </label>

                <label className="field">
                  <span className="field__label">Archivo (opcional)</span>
                  <input
                    type="file"
                    onChange={(e) => setReceipt((s) => ({ ...s, file: e.target.files?.[0] || null }))}
                    className="field__control"
                  />
                </label>

                <div className="row gap-8">
                  <button type="submit" className="btn btn--primary" disabled={uploading}>
                    {uploading ? "Enviando..." : "Enviar comprobante"}
                  </button>
                  <button type="button" className="btn btn--ghost" onClick={onClose}>Cancelar</button>
                </div>

                {uploadMsg && <div className="alert alert--ok">{uploadMsg}</div>}
              </form>
            </div>

            <div className="muted small">
              Intent #{intent.id} • Importe: {intent.amount} {intent.currency} • Creado: {new Date(intent.created_at).toLocaleString()}
            </div>
          </>
        )}

        {error && <p className="alert alert--err">{error}</p>}
      </div>
    </div>
  );
}
