// src/components/QrDialog.jsx
import { useEffect } from "react";

export default function QrDialog({ open, onClose, confirmationUrl, onScanned }) {
  useEffect(() => {
    if (!open || !confirmationUrl) return;
    // nada especial aquí; el “escaneo” real lo hacemos desde la página
  }, [open, confirmationUrl]);

  if (!open) return null;

  return (
    <div className="modal-backdrop">
      <div className="modal">
        <h3>Escanear QR</h3>
        <p>Abre este enlace en otra pestaña (o cópialo en tu celular) para simular el escaneo:</p>
        <code style={{ display: "block", wordBreak: "break-all", marginBottom: 8 }}>
          {confirmationUrl}
        </code>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => navigator.clipboard.writeText(confirmationUrl)}>Copiar</button>
          <a href={confirmationUrl} target="_blank" rel="noreferrer">
            <button>Abrir</button>
          </a>
          <button onClick={onScanned}>Ya lo escaneé</button>
          <button onClick={onClose}>Cerrar</button>
        </div>
      </div>
    </div>
  );
}
