// src/api/http.js
import { getToken } from "./auth";

export async function apiFetch(path, options = {}) {
  const headers = {
    ...(options.headers || {}),
    Authorization: getToken() ? `Token ${getToken()}` : undefined,
  };

  const res = await fetch(`${import.meta.env.VITE_API_BASE}${path}`, {
    ...options,
    headers,
  });

  if (!res.ok) {
    const detail = await res.text();
    throw new Error(`HTTP ${res.status}: ${detail}`);
  }
  return await res.json();
}
