// src/api/payments.js  (REEMPLAZO COMPLETO)

const RAW_BASE = import.meta.env.VITE_API_URL || "http://127.0.0.1:8000/api/";
const BASE = RAW_BASE.endsWith("/") ? RAW_BASE : RAW_BASE + "/";
const u = (p) => `${BASE}${String(p || "").replace(/^\/+/, "")}`;

function authHeaders(extra = {}) {
  const token = localStorage.getItem("token");
  return { ...(token ? { Authorization: `Token ${token}` } : {}), ...extra };
}

// --- helpers fetch/json
async function safeJson(res) {
  try { return await res.json(); } catch { return { detail: res.statusText || "Error" }; }
}
async function jsonFetch(pathOrUrl, { method = "GET", body, headers } = {}) {
  const url = String(pathOrUrl || "").startsWith("http") ? pathOrUrl : u(pathOrUrl);
  const r = await fetch(url, {
    method,
    headers: authHeaders({ "Content-Type": "application/json", ...(headers || {}) }),
    body: body ? JSON.stringify(body) : undefined,
  });
  const d = await safeJson(r);
  if (!r.ok) throw d;
  return d;
}
async function formFetch(pathOrUrl, formData) {
  const url = String(pathOrUrl || "").startsWith("http") ? pathOrUrl : u(pathOrUrl);
  const r = await fetch(url, { method: "POST", headers: authHeaders(), body: formData });
  const d = await safeJson(r);
  if (!r.ok) throw d;
  return d;
}

// --- normalizador de listas: [], {data:[]}, {results:[]}
function asList(x) {
  if (Array.isArray(x)) return x;
  if (Array.isArray(x?.data)) return x.data;
  if (Array.isArray(x?.results)) return x.results;
  return [];
}

// ========================= RESIDENTE =========================

// Cuotas pendientes para QR (ya probaste que este endpoint anda bien)
export async function getMisCuotas() {
  const r = await fetch(u("pagos/qr/pendientes/"), { headers: authHeaders() });
  const d = await safeJson(r);
  if (!r.ok) throw d;
  return asList(d);
}

// Firma clásica: (cuotaId, medio = "QR", amount?)
export async function crearIntentoPago(cuotaId, medio = "QR", amount) {
  return jsonFetch("pagos/mock/checkout/", { method: "POST", body: { cuota: cuotaId, medio, amount } });
}

// Firma “objeto” que usan algunos componentes: ({ cuota, medio, amount })
export async function createCheckout(arg) {
  if (typeof arg === "object" && arg) {
    const { cuota, medio = "QR", amount } = arg;
    return crearIntentoPago(cuota, medio, amount);
  }
  return crearIntentoPago(arg);
}

export async function subirComprobante({ intent, receipt_url, amount, reference, bank_name }) {
  return jsonFetch("pagos/mock/receipt/", {
    method: "POST",
    body: { intent, receipt_url, amount, reference, bank_name },
  });
}

export async function subirComprobanteArchivo({ intent, file, amount, reference, bank_name }) {
  const fd = new FormData();
  fd.append("intent", String(intent));
  if (file) fd.append("receipt_file", file);
  if (amount != null && amount !== "") fd.append("amount", String(amount));
  if (reference) fd.append("reference", reference);
  if (bank_name) fd.append("bank_name", bank_name);
  return formFetch("pagos/mock/receipt/", fd);
}

// API “inteligente” para PayModal (detecta si viene archivo o URL)
export async function uploadReceipt(payload) {
  if (payload?.file) return subirComprobanteArchivo(payload);
  return subirComprobante(payload);
}

// Simula el “escaneo” del QR (GET al landing con Authorization)
export async function getLanding(urlOrPath) {
  return jsonFetch(urlOrPath, { method: "GET" });
}

export async function getMyIntents() {
  const d = await jsonFetch("pagos/mock/intents/mine/");
  return asList(d);
}
export async function listMyIntents() { return getMyIntents(); }

// ========================= ADMIN =========================
export async function listDashboardIntents() {
  const d = await jsonFetch("pagos/mock/intents/dashboard/");
  return asList(d);
}
export async function verifyReceipt({ receipt_id, approve, note }) {
  return jsonFetch("pagos/mock/verify/", { method: "POST", body: { receipt_id, approve, note } });
}

// ==== Alias por compatibilidad con otros archivos ====
export const getDashboardIntents = listDashboardIntents;
export const verificarComprobante = verifyReceipt;
export const uploadReceiptFile = subirComprobanteArchivo;
export const getMyBills = getMisCuotas;
export const getCuotasMine = getMisCuotas;

// === NUEVO: listar comprobantes por intento ===
export async function listReceiptsByIntent(intentId) {
  // Asumimos que tu view de receipt soporta GET con filter ?intent=
  const data = await jsonFetch(`pagos/mock/receipt/?intent=${encodeURIComponent(intentId)}`);
  // Normaliza
  return Array.isArray(data) ? data : (data?.results || []);
}

// === NUEVO: listar solo pendientes (por si lo quieres usar en otro lado) ===
export async function listPendingReceipts() {
  const data = await jsonFetch("pagos/mock/receipt/?status=pending");
  return Array.isArray(data) ? data : (data?.results || []);
}