// src/pages/MisPagosPage.jsx
import { useEffect, useMemo, useState } from "react";
import { getEstadoCuenta } from "../api/estado_cuenta";
import { listMyIntents } from "../api/payments";
import PayModal from "../components/PayModal";

export default function MisPagosPage() {
  const [loading, setLoading] = useState(false);
  const [estado, setEstado] = useState(null);
  const [intents, setIntents] = useState([]);
  const [payOpen, setPayOpen] = useState(false);
  const [selectedCuota, setSelectedCuota] = useState(null);

  const cuotasConSaldo = useMemo(() => {
    const arr = estado?.cuotas || [];
    return arr.filter((c) => c.is_active && c.estado !== "ANULADA" && Number(c.saldo) > 0);
  }, [estado]);

  const refresh = async () => {
    setLoading(true);
    try {
      const ec = await getEstadoCuenta();
      setEstado(ec);
      const mine = await listMyIntents();
      setIntents(mine || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { refresh(); }, []);

  const openPay = (cuota) => {
    setSelectedCuota(cuota);
    setPayOpen(true);
  };

  return (
    <div className="page">
      <h2>Mis pagos</h2>
      {loading && <div>Cargando…</div>}

      {/* Cuotas con saldo */}
      <section>
        <h3>Cuotas pendientes</h3>
        <div className="table">
          <div className="thead">
            <div>Unidad</div><div>Periodo</div><div>Concepto</div><div>Saldo</div><div>Acción</div>
          </div>
          <div className="tbody">
            {cuotasConSaldo.map((c) => (
              <div className="tr" key={c.id}>
                <div>{c.unidad_display}</div>
                <div>{c.periodo}</div>
                <div>{c.concepto}</div>
                <div>{Number(c.saldo).toFixed(2)}</div>
                <div>
                  <button onClick={() => openPay(c)}>Pagar (QR)</button>
                </div>
              </div>
            ))}
            {cuotasConSaldo.length === 0 && <div className="tr"><div>No hay saldos.</div></div>}
          </div>
        </div>
      </section>

      {/* Mis intentos */}
      <section style={{ marginTop: 24 }}>
        <h3>Mis intentos</h3>
        <div className="table">
          <div className="thead">
            <div>ID</div><div>Cuota</div><div>Monto</div><div>Status</div><div>Creado</div><div>Pagado</div>
          </div>
          <div className="tbody">
            {intents.map((i) => (
              <div className="tr" key={i.id}>
                <div>{i.id}</div>
                <div>{i.cuota}</div>
                <div>{i.amount}</div>
                <div>{i.status}</div>
                <div>{new Date(i.created_at).toLocaleString()}</div>
                <div>{i.paid_at ? new Date(i.paid_at).toLocaleString() : "-"}</div>
              </div>
            ))}
            {intents.length === 0 && <div className="tr"><div>Sin intentos.</div></div>}
          </div>
        </div>
      </section>

      {/* Modal de pago */}
      <PayModal
        open={payOpen}
        onClose={() => setPayOpen(false)}
        cuota={selectedCuota}
        onSuccess={refresh}
      />
    </div>
  );
}
