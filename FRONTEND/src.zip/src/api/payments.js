import { apiFetch } from "./http"; // tu helper ya maneja headers y token

// --------- Resident ---------
export async function getMisCuotas() {
  return apiFetch("/cuotas/?mine=1");
}

export async function crearIntentoPago(cuotaId, medio = "QR", amount) {
  return apiFetch("/pagos/mock/checkout/", {
    method: "POST",
    body: { cuota: cuotaId, medio, amount }
  });
}

export async function subirComprobante({ intent, receipt_url, amount, reference, bank_name }) {
  return apiFetch("/pagos/mock/receipt/", {
    method: "POST",
    body: { intent, receipt_url, amount, reference, bank_name }
  });
}

// --------- Admin ---------
export async function getDashboardIntents() {
  return apiFetch("/pagos/mock/intents/dashboard/");
}

export async function verificarComprobante({ receipt_id, approve, note }) {
  return apiFetch("/pagos/mock/verify/", {
    method: "POST",
    body: { receipt_id, approve, note }
  });
}
